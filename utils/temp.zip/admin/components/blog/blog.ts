export const Blog = {
  _id: '',
  title: '',
  content: '',
};
